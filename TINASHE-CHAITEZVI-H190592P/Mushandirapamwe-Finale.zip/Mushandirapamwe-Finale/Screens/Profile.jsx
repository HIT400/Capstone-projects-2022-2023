import React, { useState, useEffect } from "react";
import {
  StyleSheet,
  Text,
  View,
  StatusBar,
  TouchableOpacity,
  Image,
  TextInput,
  KeyboardAvoidingView,
} from "react-native";
import { Icon } from "react-native-elements";
import { ListItem, Left, Right, Radio, Content } from "native-base";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { showMessage, hideMessage } from "react-native-flash-message";

export default function PaymentScreen1({ navigation }) {
  const [fullName, setFullName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [idNumber, setIdNumber] = useState("");

  const [displayIdNumber, setDisplayIdNumber] = useState("");
  const [displayPhoneNumber, setDisplayPhoneNumber] = useState("");
  const [displayFullName, setDisplayFullName] = useState("");
  const [hideOnInitialLogin, setHideOnInitialLogin] = useState("God Is Good");

  //saving and updating profile

  const submitHandler = async (value) => {
    try {
      // validation rules

      if (fullName == "" || phoneNumber == "") {
        showMessage({
          message: "Make sure  you have filled out all required fileds",
          type: "danger",
        });
        return;
      }
      if (fullName.length < 5 || phoneNumber.length < 10) {
        showMessage({
          message: "The minimum number of characters required is 10",
          type: "danger",
        });
        return;
      }

      const items = {
        fullName: fullName,
        phoneNumber: phoneNumber,
        IdNumber: idNumber,
      };
      //  console.log(items);
      // console.log(JSON.stringify(items));
      // return;
      await AsyncStorage.setItem("profileData", JSON.stringify(items));
      showMessage({
        message: "Profile has been updated successfully",
        //  description: "Update your information when neccessary",
        type: "success",
      });

      setDisplayFullName(fullName);
      setDisplayPhoneNumber(phoneNumber);
      setDisplayIdNumber(idNumber);

      setFullName("");
      setIdNumber("");
      setPhoneNumber("");
    } catch (error) {
      showMessage({
        message: error,
        description: error,
        type: "error",
      });
    }
  };

  useEffect(() => {
    StatusBar.setBarStyle("light-content", true);

    (async () => {
      try {
        const value = await AsyncStorage.getItem("profileData");
        const data = JSON.parse(value);
        // console.log(data.fullName);

        if (value !== null) {
          setDisplayFullName(data.fullName);
          setDisplayPhoneNumber(data.phoneNumber);
          setDisplayIdNumber(data.IdNumber);
          setHideOnInitialLogin("");
          // console.log(data);
        } else if (value == null) {
          showMessage({
            message: "Set up your profile to proceed",
            type: "danger",
          });
        }
      } catch (error) {
        // console.log(error)
        showMessage({
          message:
            "We are facing a trouble retrieving your info.Try again later",
          type: "error",
        });
      }
    })();
  }, []);
  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      style={styles.container}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.header}>
        <TouchableOpacity
          style={{
            paddingRight: 10,
          }}
          onPress={() => {
            navigation.goBack();
          }}
        >
          <Icon name="angle-left" type="font-awesome" size={30} color="#fff" />
        </TouchableOpacity>
      </View>
      <Text style={styles.paymentTitle}>My Profile</Text>
      <View style={styles.cartContainer}>
        <View>
          {!displayFullName || hideOnInitialLogin ? (
            <View>
              <View style={styles.couponInputView}>
                <TextInput
                  placeholder="Full Name"
                  style={styles.couponInput}
                  onChangeText={(input) => setFullName(input)}
                  value={fullName}
                />
              </View>
              <View style={styles.couponInputView}>
                <TextInput
                  placeholder="Phone Number"
                  style={styles.couponInput}
                  onChangeText={(input) => setPhoneNumber(input)}
                  keyboardType="numeric"
                  value={phoneNumber}
                />
              </View>
              <View style={styles.couponInputView}>
                <TextInput
                  placeholder="ID Number (Optional)"
                  style={styles.couponInput}
                  onChangeText={(input) => setIdNumber(input)}
                  value={idNumber}
                />
              </View>
              <TouchableOpacity
                style={styles.checkoutButton}
                onPress={submitHandler}
              >
                <Text style={styles.checkoutButtonText}>Update Profile</Text>
              </TouchableOpacity>

              {/* my credentials section */}
            </View>
          ) : (
            <View>
              <View style={styles.subtotalView}>
                <Text style={styles.subtotalText}>My Creditentials</Text>
                <Text style={styles.subtotalPrice}></Text>
              </View>
              <Image
                source={require("../assets/category-icons/no-profile.png")}
                style={styles.coverImage}
              />
              <View style={styles.shippingView}>
                <View style={styles.shippingItemsView}>
                  <Text>Name: {displayFullName ? displayFullName : " "}</Text>
                </View>
                <View style={styles.shippingItemsView}>
                  <Text>
                    Phone Number:{" "}
                    {displayPhoneNumber ? displayPhoneNumber : " "}
                  </Text>
                </View>
                <View style={styles.shippingItemsView}>
                  <Text>
                    ID Number: {displayIdNumber ? displayIdNumber : " "}
                  </Text>
                </View>
              </View>
            </View>
          )}

          <View style={{ height: 100 }}></View>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F9FAFB",
    paddingTop: StatusBar.currentHeight,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    padding: 10,
    backgroundColor: "#3f51b5",
  },
  paymentTitle: {
    fontSize: 32,
    fontWeight: "bold",
    color: "#212529",
    textAlign: "center",
    marginVertical: 20,
  },
  cartContainer: {
    flex: 1,
    paddingHorizontal: 20,
  },
  couponInputView: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#E5E5E5",
    borderRadius: 10,
    marginVertical: 10,
    backgroundColor: "#FFFFFF",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  couponInput: {
    flex: 1,
    padding: 10,
    fontSize: 16,
    color: "#212529",
  },
  checkoutButton: {
    backgroundColor: "#3f51b5",
    borderRadius: 10,
    paddingVertical: 15,
    marginVertical: 20,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  checkoutButtonText: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#FFFFFF",
    textAlign: "center",
  },
  icon: {
    marginRight: 5,
    color: "#3f51b5",
  },
});

