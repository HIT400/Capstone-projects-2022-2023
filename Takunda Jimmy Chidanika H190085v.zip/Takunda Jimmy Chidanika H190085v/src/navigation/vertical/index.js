// ** Icon imports
import HomeOutline from 'mdi-material-ui/HomeOutline'
import AccountCogOutline from 'mdi-material-ui/AccountCogOutline'
import {HospitalBoxOutline, PlusOutline, TimelineClock, ViewListOutline} from "mdi-material-ui";
import {useAppContext} from "../../../context";


const navigation = () => {
    const userRole = localStorage.getItem("userRole")
    if(userRole === "PATIENT"){
        return [
            {
                sectionTitle: 'Patient'
            },
            {
                title: 'Dashboard',
                icon: HomeOutline,
                path: '/patient'
            },
            {
                title: 'All Doctors',
                icon: HospitalBoxOutline,
                path: '/patient/doctors'
            },
            {
                title: 'Authorized Doctors',
                icon: ViewListOutline,
                path: '/patient/authorized'
            },
            {
                title: 'Add Record',
                icon: PlusOutline,
                path: '/patient/add-medical-record'
            },
            {
                title: 'Account Details',
                icon: AccountCogOutline,
                path: '/patient/details'
            },

        ]
    }
    if(userRole === "DOCTOR"){
        return [
            {
                sectionTitle: 'Doctor'
            },
            {
                title: 'Dashboard',
                icon: HomeOutline,
                path: '/doctor'
            },
            {
                title: 'Pending',
                icon: TimelineClock,
                path: '/doctor/pending'
            },
            {
                title: 'View Details',
                icon: AccountCogOutline,
                path: '/doctor/details'
            }
        ]
    }
}

export default navigation
