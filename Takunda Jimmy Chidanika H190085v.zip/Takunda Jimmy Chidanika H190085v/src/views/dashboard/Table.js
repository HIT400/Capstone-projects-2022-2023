// ** MUI Imports
import Card from '@mui/material/Card'
import Chip from '@mui/material/Chip'
import Table from '@mui/material/Table'
import TableRow from '@mui/material/TableRow'
import TableHead from '@mui/material/TableHead'
import TableBody from '@mui/material/TableBody'
import TableCell from '@mui/material/TableCell'
import TableContainer from '@mui/material/TableContainer'
import CardHeader from "@mui/material/CardHeader";

const statusObj = {
    true: {color: 'success'},
    false: {color: 'warning'},
}

const DashboardTable = ({records}) => {
    return (
        <Card>
            <CardHeader title='Medical Records' titleTypographyProps={{variant: 'h6'}}/>
            <TableContainer>
                <Table sx={{minWidth: 800}} aria-label='table in dashboard'>
                    <TableHead>
                        <TableRow>
                            <TableCell>timestamp</TableCell>
                            <TableCell>symptoms</TableCell>
                            <TableCell>temperature</TableCell>
                            <TableCell>heart rate</TableCell>
                            <TableCell>diagnosis</TableCell>
                            <TableCell>treatment</TableCell>
                            <TableCell>treated</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {records.map((row, index)=> (
                            <TableRow hover key={index} sx={{'&:last-of-type td, &:last-of-type th': {border: 0}}}>
                                <TableCell>{row.timestamp}</TableCell>
                                <TableCell>{row.symptoms}</TableCell>
                                <TableCell>{row.temperature}</TableCell>
                                <TableCell>{row.heartRate}</TableCell>
                                <TableCell>{row.treatment}</TableCell>
                                <TableCell>{row.diagnosis}</TableCell>
                                <TableCell>
                                    <Chip
                                        label={row.treated}
                                        color={statusObj[row.treated].color}
                                        sx={{
                                            height: 24,
                                            fontSize: '0.75rem',
                                            textTransform: 'capitalize',
                                            '& .MuiChip-label': {fontWeight: 500}
                                        }}
                                    />
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
        </Card>
    )
}

export default DashboardTable
