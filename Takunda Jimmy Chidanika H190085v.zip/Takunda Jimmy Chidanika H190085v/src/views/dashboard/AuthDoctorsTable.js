// ** MUI Imports
import Card from '@mui/material/Card'
import Table from '@mui/material/Table'
import TableRow from '@mui/material/TableRow'
import TableHead from '@mui/material/TableHead'
import TableBody from '@mui/material/TableBody'
import TableCell from '@mui/material/TableCell'
import TableContainer from '@mui/material/TableContainer'
import Button from "@mui/material/Button";
import {useState} from "react";
import {useAppContext} from "../../../context";
import {useAddress} from "@thirdweb-dev/react";

const statusObj = {
    true: {color: 'success'},
    false: {color: 'warning'},
}

const AuthDoctorsTable = ({doctors}) => {
    const {revokeAccess} = useAppContext();
    const address = useAddress();
    const [form, setForm] = useState({
        patientAddress: '',
        doctorAddress: '',
    })
    async function takeAccess(doctorAddress) {
        setForm({
            doctorAddress: doctorAddress,
            patientAddress: address,
        });
        await revokeAccess({...form});
    }

    return (
        <Card>
            <TableContainer>
                <Table sx={{minWidth: 800}} aria-label='table in dashboard'>
                    <TableHead>
                        <TableRow>
                            <TableCell>firstname</TableCell>
                            <TableCell>middlename</TableCell>
                            <TableCell>lastname</TableCell>
                            <TableCell>gender</TableCell>
                            <TableCell>email</TableCell>
                            <TableCell>speciality</TableCell>
                            <TableCell>Short Description</TableCell>
                            <TableCell>Physical Address</TableCell>
                            <TableCell>Action</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {doctors.map((row, index) => (
                            <TableRow hover key={index} sx={{'&:last-of-type td, &:last-of-type th': {border: 0}}}>
                                <TableCell>{row.firstname}</TableCell>
                                <TableCell>{row.middlename}</TableCell>
                                <TableCell>{row.lastname}</TableCell>
                                <TableCell>{row.gender}</TableCell>
                                <TableCell>{row.email}</TableCell>
                                <TableCell>{row.speciality}</TableCell>
                                <TableCell>{row.shortDescription}</TableCell>
                                <TableCell>{row.physicalAddress}</TableCell>
                                <TableCell>
                                    <Button  size='small'
                                             onClick={() => takeAccess(
                                                 row.owner
                                             )}
                                             color={"error"} variant='contained' sx={{width: '100%'}}>
                                        Revoke Access
                                    </Button>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
        </Card>
    )
}

export default AuthDoctorsTable
