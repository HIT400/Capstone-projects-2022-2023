// ** MUI Imports
import Card from '@mui/material/Card'
import Table from '@mui/material/Table'
import TableRow from '@mui/material/TableRow'
import TableHead from '@mui/material/TableHead'
import TableBody from '@mui/material/TableBody'
import TableCell from '@mui/material/TableCell'
import TableContainer from '@mui/material/TableContainer'
import Button from "@mui/material/Button";
import {useRouter} from "next/router";

const statusObj = {
  true: {color: 'success'},
  false: {color: 'warning'},
}

const PatientsTable = ({patients}) => {
  const router = useRouter();
  const viewRecords = async (address) => {
    await router.push(`/doctor/records?param=${address}`)
  }

  return (
    <Card>
      <TableContainer>
        <Table sx={{minWidth: 800}} aria-label='table in dashboard'>
          <TableHead>
            <TableRow>
              <TableCell>Firstname</TableCell>
              <TableCell>Middlename</TableCell>
              <TableCell>Lastname</TableCell>
              <TableCell>Gender</TableCell>
              <TableCell>Email</TableCell>
              <TableCell>Emergency Contact</TableCell>
              <TableCell>Home Address</TableCell>
              <TableCell>View Records</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {patients.map(row => (
              <TableRow hover key={row.name} sx={{'&:last-of-type td, &:last-of-type th': {border: 0}}}>
                <TableCell>{row.firstname}</TableCell>
                <TableCell>{row.middlename}</TableCell>
                <TableCell>{row.lastname}</TableCell>
                <TableCell>{row.gender}</TableCell>
                <TableCell>{row.email}</TableCell>
                <TableCell>{row.emergencyContact}</TableCell>
                <TableCell>{row.homeAddress}</TableCell>
                <TableCell><Button  size='small'
                                    onClick={()=> viewRecords(row.patientAddress)}
                                    color={"primary"} variant='contained' sx={{width: '100%'}}>
                  View Records
                </Button></TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Card>
  )
}

export default PatientsTable
