// ** React Imports
import {useEffect, useState} from 'react'

// ** Next Imports

// ** MUI Components
import { create } from 'ipfs-http-client';
import {useAppContext} from "../../context";


// ** Icons Imports

const LoginPage = () => {

    const {uploadFiles} = useAppContext();

    const handleFileChange = async (event) => {
       const links = await uploadFiles(event);
        console.log(links)
    }

    return (
        <div className="App">
            <br/>
            <input type="file" multiple onChange={handleFileChange} />
        </div>
    );
}
export default LoginPage
