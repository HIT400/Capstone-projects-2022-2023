// ** React Imports
import {useEffect, useState} from 'react'

// ** MUI Imports
import Card from '@mui/material/Card'
import Grid from '@mui/material/Grid'
import Button from '@mui/material/Button'
import Divider from '@mui/material/Divider'
import MenuItem from '@mui/material/MenuItem'
import TextField from '@mui/material/TextField'
import CardHeader from '@mui/material/CardHeader'
import InputLabel from '@mui/material/InputLabel'
import CardContent from '@mui/material/CardContent'
import CardActions from '@mui/material/CardActions'
import FormControl from '@mui/material/FormControl'
import Select from '@mui/material/Select'

// ** Third Party Imports

// ** Icons Imports
import ApexChartWrapper from "../../../@core/styles/libs/react-apexcharts";
import {useAppContext} from "../../../../context";
import {useAddress} from "@thirdweb-dev/react";
import {useRouter} from "next/router";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";

const UpdateMedicalRecord = () => {

  const {getMedicalRecord, updateMedicalRecord} = useAppContext();
  const router = useRouter();
  const { param} = router.query;
  const [record, setRecord] = useState({
    recordId:1,
    patientAddress: '',
    doctorAddress: '',
    createdAt:'',
    symptoms: '',
    temperature: '',
    heartRate: '',
    diagnosis: '',
    treatment: '',
    files: '',
    treatedAt:'',
  })

  const fetchData = async () => {
    const data = await getMedicalRecord(param);
    console.log(data);
    setRecord(data);
    console.log(record)

  }

  useEffect(() => {
    fetchData();

  }, []);


  const handleFormFieldChange = (fieldName, e) => {
    setRecord({...record, [fieldName]: e.target.value})
  }

  const handleSubmit = async (e) => {
    const now = new Date();
    setRecord({...record,recordId:record.recordId, patientAddress: record.patientAddress,doctorAddress:record.doctorAddress, treatedAt:now.toString()});
    console.log(record);
    e.preventDefault();
    await updateMedicalRecord({...record})
  }

  return (
      <ApexChartWrapper>
        <Grid container spacing={6}>
          <Grid item xs={12}>
            <Card>
              <CardHeader title='Update Medical Record' titleTypographyProps={{variant: 'h6'}}/>
              <Divider sx={{margin: 0}}/>
              <form onSubmit={handleSubmit}>
                <CardContent>

                  <Grid container spacing={5}>
                    <Grid item xs={6}>
                      <TextField
                          fullWidth
                          multiline
                          minRows={3}
                          defaultValue={record.createdAt}
                          value={record.createdAt}
                          readonly={true}
                          label='CreateAt'
                          readOnly={true}
                      />
                    </Grid>
                    <Grid item xs={6}>
                      <TextField
                          fullWidth
                          multiline
                          minRows={3}
                          defaultValue={record.symptoms}
                          value={record.symptoms}
                          readonly={true}
                          label='Symptoms'
                          placeholder='Headache'
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <TextField
                          fullWidth
                          label='Temperature'
                          defaultValue={record.temperature}
                          readonly={true}
                          value={record.temperature}
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <TextField fullWidth
                                 label='Heart Rate'
                                 defaultValue={record.heartRate}
                                 readonly={true}
                                 value={record.heartRate}

                      />
                    </Grid>
                    <Grid item xs={6}>
                      <TextField
                          fullWidth
                          multiline
                          minRows={3}
                          label='Diagnosis'
                          placeholder='Add Diagnosis...'
                          value={record.diagnosis}
                          onChange={(e)=>handleFormFieldChange(
                              "diagnosis",e
                          )}
                      />
                    </Grid>
                    <Grid item xs={6}>
                      <TextField
                          fullWidth
                          multiline
                          minRows={3}
                          label='Treatment'
                          placeholder='Add Treatment...'
                          value={record.treatment}
                          onChange={(e)=>handleFormFieldChange(
                              "treatment",e
                          )}
                      />
                    </Grid>
                  </Grid>
                </CardContent>
                <Divider sx={{margin: 0}}/>
                <CardActions>
                  <Button size='large' type='submit' sx={{mr: 2}} variant='contained'>
                    Submit
                  </Button>
                  <Button size='large' color='secondary' variant='outlined'>
                    Cancel
                  </Button>
                </CardActions>
              </form>
            </Card>
          </Grid>
        </Grid>
      </ApexChartWrapper>
  )
}

export default UpdateMedicalRecord
