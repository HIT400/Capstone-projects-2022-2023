import ApexChartWrapper from 'src/@core/styles/libs/react-apexcharts';
import Grid from '@mui/material/Grid'
import CardHeader from "@mui/material/CardHeader";
import CardContent from "@mui/material/CardContent";
import Card from "@mui/material/Card";
import Box from "@mui/material/Box";
import Avatar from "@mui/material/Avatar";
import Typography from "@mui/material/Typography";
import {HospitalBox, PlusBoxOutline} from "mdi-material-ui";
import PatientsTable from "../../views/dashboard/PatientsTable";
import {useEffect, useState} from "react";
import {useAddress} from "@thirdweb-dev/react";
import {useAppContext} from "../../../context";
const Dashboard = () => {

    const {getPatientByDoctorId} = useAppContext();
    const address = useAddress();
    const [patients, setPatients] = useState([])

    const fetchData = async () => {
        const address = localStorage.getItem("userAddress");
        const data = await getPatientByDoctorId(address);
        setPatients(data);
        console.log(patients);
    }

    useEffect(() => {
        fetchData(address);
    }, []);


    return (
        <ApexChartWrapper>
            <Grid container spacing={6}>
                <Grid item xs={12} md={12}>
                    <Card>
                        <CardHeader
                            title='Patient Stats'
                            titleTypographyProps={{
                                sx: {
                                    mb: 1.0,
                                    lineHeight: '2rem !important',
                                    letterSpacing: '0.15px !important'
                                }
                            }}
                        />
                        <CardContent sx={{pt: theme => `${theme.spacing(3)} !important`}}>
                            <Grid container spacing={[5, 0]}>
                                <Grid item xs={12} sm={3} >
                                    <Box sx={{display: 'flex', alignItems: 'center'}}>
                                        <Avatar
                                            variant='rounded'
                                            sx={{
                                                mr: 3,
                                                width: 44,
                                                height: 44,
                                                boxShadow: 3,
                                                color: 'common.white',
                                                backgroundColor: `primary.main`
                                            }}
                                        >
                                            <PlusBoxOutline/>
                                        </Avatar>
                                        <Box sx={{display: 'flex', flexDirection: 'column'}}>
                                            <Typography variant='caption'>Total Number Of Doctors</Typography>
                                            <Typography variant='h6'>12</Typography>
                                        </Box>
                                    </Box>
                                </Grid>
                            </Grid>
                        </CardContent>
                    </Card>
                </Grid>
                <Grid item xs={12}>
                    <PatientsTable patients={patients}/>
                </Grid>
            </Grid>
        </ApexChartWrapper>
    )
}

export default Dashboard
