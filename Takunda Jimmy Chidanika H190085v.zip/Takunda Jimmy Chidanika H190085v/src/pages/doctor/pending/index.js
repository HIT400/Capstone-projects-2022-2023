import ApexChartWrapper from 'src/@core/styles/libs/react-apexcharts';
import Grid from '@mui/material/Grid'
import CardHeader from "@mui/material/CardHeader";
import CardContent from "@mui/material/CardContent";
import Card from "@mui/material/Card";
import Box from "@mui/material/Box";
import Avatar from "@mui/material/Avatar";
import Typography from "@mui/material/Typography";
import {HospitalBox} from "mdi-material-ui";
import PendingTable from "../../../views/dashboard/PendingTable";
import {useEffect, useState} from "react";
import {useAppContext} from "../../../../context";
import {useAddress} from "@thirdweb-dev/react";

const patientStats = [
    {
        stats: '24',
        title: 'Total Number Of Pending Treatments',
        color: 'primary',
        icon: <HospitalBox sx={{fontSize: '1.75rem'}}/>
    },
]
const renderStats = () => {
    return patientStats.map((item, index) => (
        <Grid item xs={12} sm={3} key={index}>
            <Box key={index} sx={{display: 'flex', alignItems: 'center'}}>
                <Avatar
                    variant='rounded'
                    sx={{
                        mr: 3,
                        width: 44,
                        height: 44,
                        boxShadow: 3,
                        color: 'common.white',
                        backgroundColor: `${item.color}.main`
                    }}
                >
                    {item.icon}
                </Avatar>
                <Box sx={{display: 'flex', flexDirection: 'column'}}>
                    <Typography variant='caption'>{item.title}</Typography>
                    <Typography variant='h6'>{item.stats}</Typography>
                </Box>
            </Box>
        </Grid>
    ))
}
const Pending = () => {
    const {getMedicalRecordsByDoctor} = useAppContext();
    const address = useAddress();
    const [records, setRecords] = useState([])

    const fetchData = async () => {
        const data = await getMedicalRecordsByDoctor(address);
        setRecords(data.filter(a => a.treated === "false"));
        console.log("This Function");
        console.log(data);
    }

    useEffect(() => {
        fetchData();
    }, []);
    return (
        <ApexChartWrapper>
            <Grid container spacing={6}>
                <Grid item xs={12} md={12}>
                    <Card>
                        <CardHeader
                            title='Pending Stats'
                            titleTypographyProps={{
                                sx: {
                                    mb: 1.0,
                                    lineHeight: '2rem !important',
                                    letterSpacing: '0.15px !important'
                                }
                            }}
                        />
                        <CardContent sx={{pt: theme => `${theme.spacing(3)} !important`}}>
                            <Grid container spacing={[5, 0]}>
                                {renderStats()}
                            </Grid>
                        </CardContent>
                    </Card>
                </Grid>
                <Grid item xs={12}>
                    <PendingTable records={records}/>
                </Grid>
            </Grid>
        </ApexChartWrapper>
    )
}

export default Pending
