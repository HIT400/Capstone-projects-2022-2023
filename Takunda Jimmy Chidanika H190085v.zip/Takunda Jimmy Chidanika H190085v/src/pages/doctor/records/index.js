// ** MUI Imports
import Grid from '@mui/material/Grid'

// ** Icons Imports
// ** Custom Components Imports
// ** Styled Component Import
import ApexChartWrapper from 'src/@core/styles/libs/react-apexcharts'

// ** Demo Components Imports
import {useEffect, useState} from "react";
import {useAddress} from "@thirdweb-dev/react";
import {useAppContext} from "../../../../context";
import {useRouter} from "next/router";
import Typography from "@mui/material/Typography";
import RecordsTable from "../../../views/dashboard/RecordsTable";
import Card from "@mui/material/Card";
import CardHeader from "@mui/material/CardHeader";
import CardContent from "@mui/material/CardContent";
import Box from "@mui/material/Box";
import Avatar from "@mui/material/Avatar";
import {HeartFlash, TemperatureCelsius} from "mdi-material-ui";

const PatientStatisticsCard = ({records}) => {
    const [data, setData] = useState({
        heartRate: '',
        temperature: '',
    });

    useEffect(() => {
        const fetchData = async () => {
            const res = await fetch('http://localhost:9090/iot/latest/patient-1@gmail.com');
            const newData = await res.json();
            setData(newData);
        };

        // Fetch data initially and start timer
        fetchData();
        const timerId = setInterval(() => {
            fetchData();
        }, 1000);

        // Clean up timer when component unmounts
        return () => clearTimeout(timerId);
    }, []);

    return (
        <Card>
            <CardHeader
                title='Health Vitals'
                titleTypographyProps={{
                    sx: {
                        mb: 1.0,
                        lineHeight: '2rem !important',
                        letterSpacing: '0.15px !important'
                    }
                }}
            />
            <CardContent sx={{pt: theme => `${theme.spacing(3)} !important`}}>
                <Grid container spacing={[5, 0]}>
                    <Grid item xs={12} sm={3}>
                        <Box sx={{display: 'flex', alignItems: 'center'}}>
                            <Avatar
                                variant='rounded'
                                sx={{
                                    mr: 3,
                                    width: 44,
                                    height: 44,
                                    boxShadow: 3,
                                    color: 'common.white',
                                    backgroundColor: `primary.main`
                                }}
                            >
                                <TemperatureCelsius sx={{fontSize: '1.75rem'}}/>
                            </Avatar>
                            <Box sx={{display: 'flex', flexDirection: 'column'}}>
                                <Typography variant='caption'>Temperature</Typography>
                                <Typography variant='h6'>{data.temperature}</Typography>
                            </Box>
                        </Box>
                    </Grid>
                    <Grid item xs={12} sm={3}>
                        <Box sx={{display: 'flex', alignItems: 'center'}}>
                            <Avatar
                                variant='rounded'
                                sx={{
                                    mr: 3,
                                    width: 44,
                                    height: 44,
                                    boxShadow: 3,
                                    color: 'common.white',
                                    backgroundColor: `primary.main`
                                }}
                            >
                                <HeartFlash sx={{fontSize: '1.75rem'}}/>
                            </Avatar>
                            <Box sx={{display: 'flex', flexDirection: 'column'}}>
                                <Typography variant='caption'>Beat Per Minute</Typography>
                                <Typography variant='h6'>{data.heartRate}</Typography>
                            </Box>
                        </Box>
                    </Grid>
                    <Grid item xs={12} sm={3}>
                        <Box sx={{display: 'flex', alignItems: 'center'}}>
                            <Avatar
                                variant='rounded'
                                sx={{
                                    mr: 3,
                                    width: 44,
                                    height: 44,
                                    boxShadow: 3,
                                    color: 'common.white',
                                    backgroundColor: `primary.main`
                                }}
                            >
                                <HeartFlash sx={{fontSize: '1.75rem'}}/>
                            </Avatar>
                            <Box sx={{display: 'flex', flexDirection: 'column'}}>
                                <Typography variant='caption'>Total Records</Typography>
                                <Typography variant='h6'>{records.length}</Typography>
                            </Box>
                        </Box>
                    </Grid>
                </Grid>
            </CardContent>
        </Card>
    )
}
const Records = () => {
    const [records, setRecords] = useState([])
    const address = useAddress();
    const router = useRouter();
    const {param} = router.query;
    const {getMedicalRecords, getPatient} = useAppContext();
    const fetchRecords = async () => {
        console.log("PARAM", param);
        const data = await getMedicalRecords(param);
        await getPatient(address);
        setRecords(data);
        console.log("records")
    };

    useEffect(() => {
        fetchRecords();
    }, []);

    return (<ApexChartWrapper>
        <Grid container spacing={6}>
            <Grid item xs={12} md={12}>
                <PatientStatisticsCard records={records}/>
            </Grid>
            <Grid item xs={12}>
                <RecordsTable records={records}/>
            </Grid>
        </Grid>
    </ApexChartWrapper>)
}

export default Records
