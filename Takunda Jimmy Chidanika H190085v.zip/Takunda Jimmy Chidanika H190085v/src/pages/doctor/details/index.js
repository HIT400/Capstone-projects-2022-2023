// ** React Imports
import {useEffect, useState} from 'react'

// ** MUI Imports
import Grid from '@mui/material/Grid'
import Button from '@mui/material/Button'
import MenuItem from '@mui/material/MenuItem'
import TextField from '@mui/material/TextField'
import InputLabel from '@mui/material/InputLabel'
import CardContent from '@mui/material/CardContent'
import FormControl from '@mui/material/FormControl'
import Select from '@mui/material/Select'

// ** Third Party Imports
// ** Icons Imports
import ApexChartWrapper from "../../../@core/styles/libs/react-apexcharts";
import {useAppContext} from "../../../../context";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import {styled} from "@mui/material/styles";
import {useAddress, useMetamask} from "@thirdweb-dev/react";
import {wait} from "next/dist/build/output/log";

const ImgStyled = styled('img')(({theme}) => ({
    width: 120,
    height: 120,
    marginRight: theme.spacing(6.25),
    borderRadius: theme.shape.borderRadius
}))

const ButtonStyled = styled(Button)(({theme}) => ({
    [theme.breakpoints.down('sm')]: {
        width: '100%',
        textAlign: 'center'
    }
}))

const ResetButtonStyled = styled(Button)(({theme}) => ({
    marginLeft: theme.spacing(4.5),
    [theme.breakpoints.down('sm')]: {
        width: '100%',
        marginLeft: 0,
        textAlign: 'center',
        marginTop: theme.spacing(4)
    }
}))
const PatientDetails = () => {

    const [form, setForm] = useState({
        owner:'',
        firstname: '',
        middlename: '',
        lastname: '',
        gender: '',
        dob: '',
        email: '',
        speciality: '',
        shortDescription: '',
        physicalAddress: '',
    })

    const {getDoctor, updateDoctor} = useAppContext();
    const address = useAddress();
    const fetchPatient = async (address) => {
        if(address){
            const data = await getDoctor(address);
            setForm(data);
        }

        console.log(form);
    };

    useEffect(() => {
        fetchPatient(address);

    }, []);

    const onChange = file => {
        const reader = new FileReader()
        const {files} = file.target
        if (files && files.length !== 0) {
            reader.onload = () => setImgSrc(reader.result)
            reader.readAsDataURL(files[0])
        }
    }

    const handleFormFieldChange = (fieldName, e) => {
        setForm({...form, [fieldName]: e.target.value})
    }

    const handleSubmit = async (e) => {
        setForm({...form,owner:address});
        e.preventDefault();
        await updateDoctor({...form});

    }
    const [imgSrc, setImgSrc] = useState('/images/avatars/1.png')

    return (
        <ApexChartWrapper>
            <Grid container spacing={6}>
                <Grid item xs={12}>
                    <CardContent>
                        <form onSubmit={handleSubmit}>
                            <Grid container spacing={7}>
                                <Grid item xs={12} sx={{marginTop: 4.8, marginBottom: 3}}>
                                    <Box sx={{display: 'flex', alignItems: 'center'}}>
                                        <ImgStyled src={imgSrc} alt='Profile Pic'/>
                                        <Box>
                                            <ButtonStyled component='label' variant='contained'
                                                          htmlFor='account-settings-upload-image'>
                                                Upload New Photo
                                                <input
                                                    hidden
                                                    type='file'
                                                    onChange={onChange}
                                                    accept='image/png, image/jpeg'
                                                    id='account-settings-upload-image'
                                                />
                                            </ButtonStyled>
                                            <ResetButtonStyled color='error' variant='outlined'
                                                               onClick={() => fetchPatient()}>
                                                Refresh
                                            </ResetButtonStyled>
                                            <Typography variant='body2' sx={{marginTop: 5}}>
                                                Allowed PNG or JPEG. Max size of 800K.
                                            </Typography>
                                        </Box>
                                    </Box>
                                </Grid>
                                <Grid item xs={12} sm={6}>
                                    <TextField fullWidth
                                               label='Firstname'
                                               placeholder='Takunda'
                                               defaultValue={form.firstname}
                                               value={form.firstname}
                                               onChange={(e) => handleFormFieldChange(
                                                   'firstname', e
                                               )}
                                    />
                                </Grid>
                                <Grid item xs={12} sm={6}>
                                    <TextField fullWidth
                                               label='Middlename'
                                               placeholder='Jimmy'
                                               defaultValue={form.middlename}
                                               value={form.middlename}
                                               onChange={(e) => handleFormFieldChange(
                                                   'middlename', e
                                               )}
                                    />
                                </Grid>
                                <Grid item xs={12} sm={6}>
                                    <TextField
                                        fullWidth
                                        label='Lastname'
                                        placeholder='Chidanika'
                                        value={form.lastname}
                                        defaultValue={form.lastname}
                                        onChange={(e) => handleFormFieldChange(
                                            'lastname', e
                                        )}
                                    />

                                </Grid>
                                <Grid item xs={12} sm={6}>
                                    <FormControl fullWidth>
                                        <InputLabel id='form-layouts-separator-select-label'>Gender</InputLabel>
                                        <Select
                                            label='Gender'
                                            value={form.gender}
                                            defaultValue={form.gender}
                                            id='form-layouts-separator-select'
                                            labelId='form-layouts-separator-select-label'
                                            onChange={(e) => handleFormFieldChange(
                                                'gender', e
                                            )}
                                        >
                                            <MenuItem value='MALE'>MALE</MenuItem>
                                            <MenuItem value='FEMALE'>FEMALE</MenuItem>

                                        </Select>
                                    </FormControl>
                                </Grid>
                                <Grid item xs={12} sm={6}>
                                    <TextField fullWidth
                                               type='date'
                                               label='Date Of Birth'
                                               placeholder='2023-12-12'
                                               value={form.dob}
                                               defaultValue={form.dob}
                                               onChange={(e) => handleFormFieldChange(
                                                   'dob', e
                                               )}
                                    />
                                </Grid>
                                <Grid item xs={12} sm={6}>
                                    <TextField fullWidth
                                               type='email'
                                               label='Email'
                                               placeholder='tjchidanika@gmail.com'
                                               value={form.email}
                                               defaultValue={form.email}
                                               onChange={(e) => handleFormFieldChange(
                                                   'email', e
                                               )}
                                    />
                                </Grid>
                                <Grid item xs={12} sm={6}>
                                    <TextField fullWidth
                                               label='Speciality'
                                               placeholder='tjchidanika@gmail.com'
                                               value={form.speciality}
                                               defaultValue={form.speciality}
                                               onChange={(e) => handleFormFieldChange(
                                                   'speciality', e
                                               )}
                                    />
                                </Grid>
                                <Grid item xs={12} sm={6}>
                                    <TextField fullWidth
                                               label='Physical Address'
                                               placeholder='UZ'
                                               value={form.physicalAddress}
                                               defaultValue={form.physicalAddress}
                                               onChange={(e) => handleFormFieldChange(
                                                   'physicalAddress', e
                                               )}
                                    />
                                </Grid>
                                <Grid item xs={12}>
                                    <TextField
                                        fullWidth
                                        multiline
                                        minRows={3}
                                        value={form.shortDescription}
                                        defaultValue={form.shortDescription}
                                        label='Short Description'
                                        placeholder='Short Description ....'
                                        onChange={(e) => handleFormFieldChange(
                                            'shortDescription', e
                                        )}
                                    />
                                </Grid>
                                <Grid item xs={12}>
                                    <Button type="submit" variant='contained' sx={{marginRight: 3.5}}>
                                        Save Changes
                                    </Button>
                                    <Button type='reset' variant='outlined' color='secondary'>
                                        Reset
                                    </Button>
                                </Grid>
                            </Grid>
                        </form>
                    </CardContent>
                </Grid>
            </Grid>
        </ApexChartWrapper>
    )
}

export default PatientDetails
