// ** React Imports
import {useEffect, useState} from 'react'

// ** MUI Imports
import Grid from '@mui/material/Grid'
import Button from '@mui/material/Button'
import MenuItem from '@mui/material/MenuItem'
import TextField from '@mui/material/TextField'
import InputLabel from '@mui/material/InputLabel'
import CardContent from '@mui/material/CardContent'
import FormControl from '@mui/material/FormControl'
import Select from '@mui/material/Select'

// ** Third Party Imports
// ** Icons Imports
import ApexChartWrapper from "../../../@core/styles/libs/react-apexcharts";
import {useAppContext} from "../../../../context";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import {styled} from "@mui/material/styles";
import {useAddress} from "@thirdweb-dev/react";
import {wait} from "next/dist/build/output/log";

const ImgStyled = styled('img')(({theme}) => ({
    width: 120,
    height: 120,
    marginRight: theme.spacing(6.25),
    borderRadius: theme.shape.borderRadius
}))

const ButtonStyled = styled(Button)(({theme}) => ({
    [theme.breakpoints.down('sm')]: {
        width: '100%',
        textAlign: 'center'
    }
}))

const ResetButtonStyled = styled(Button)(({theme}) => ({
    marginLeft: theme.spacing(4.5),
    [theme.breakpoints.down('sm')]: {
        width: '100%',
        marginLeft: 0,
        textAlign: 'center',
        marginTop: theme.spacing(4)
    }
}))
const PatientDetails = () => {
    const [patient, setPatient] = useState({
        firstname: '',
        middlename: '',
        lastname: '',
        gender: '',
        dob: '',
        email: '',
        emergencyContact: '',
        homeAddress: '',
    });
    const {getPatient, updatePatient, userAddress} = useAppContext();
    const address = useAddress();
    console.log("User Details",userAddress);
    const fetchPatient = async (_address) => {

        const data = await getPatient(_address);
        setPatient(data);
        console.log(patient);
    };

    useEffect(() => {
        fetchPatient(address);

    }, []);

    const onChange = file => {
        const reader = new FileReader()
        const {files} = file.target
        if (files && files.length !== 0) {
            reader.onload = () => setImgSrc(reader.result)
            reader.readAsDataURL(files[0])
        }
    }


    const handleFormFieldChange = (fieldName, e) => {
        setPatient({...patient, [fieldName]: e.target.value})
    }

    const handleSubmit = async (e) => {
        console.log(patient);
        e.preventDefault();
        await updatePatient({...patient}, address);

    }
    const [imgSrc, setImgSrc] = useState('/images/avatars/1.png')

    return (
        <ApexChartWrapper>
            <Grid container spacing={6}>
                <Grid item xs={12}>
                    <CardContent>
                        <form onSubmit={handleSubmit}>
                            <Grid container spacing={7}>
                                <Grid item xs={12} sx={{marginTop: 4.8, marginBottom: 3}}>
                                    <Box sx={{display: 'flex', alignItems: 'center'}}>
                                        <ImgStyled src={imgSrc} alt='Profile Pic'/>
                                        <Box>
                                            <ButtonStyled component='label' variant='contained'
                                                          htmlFor='account-settings-upload-image'>
                                                Upload New Photo
                                                <input
                                                    hidden
                                                    type='file'
                                                    onChange={onChange}
                                                    accept='image/png, image/jpeg'
                                                    id='account-settings-upload-image'
                                                />
                                            </ButtonStyled>
                                            <ResetButtonStyled color='error' variant='outlined'
                                                               onClick={() => setImgSrc('/images/avatars/1.png')}>
                                                Reset
                                            </ResetButtonStyled>
                                            <Typography variant='body2' sx={{marginTop: 5}}>
                                                Allowed PNG or JPEG. Max size of 800K.
                                            </Typography>
                                        </Box>
                                    </Box>
                                </Grid>
                                <Grid item xs={12} sm={6}>
                                    <TextField fullWidth label='Firstaname' placeholder='Takunda'
                                               defaultValue={patient.firstname} value={patient.firstname}
                                               onChange={(e) => handleFormFieldChange(
                                                   'firstname', e
                                               )}
                                    />
                                </Grid>
                                <Grid item xs={12} sm={6}>
                                    <TextField fullWidth label='Middlename' placeholder='Jimmy'
                                               defaultValue={patient.middlename} value={patient.middlename}
                                               onChange={(e) => handleFormFieldChange(
                                                   'middlename', e
                                               )}
                                    />
                                </Grid>
                                <Grid item xs={12} sm={6}>
                                    <TextField fullWidth label='Lastname' placeholder='Chidanika'
                                               defaultValue={patient.lastname} value={patient.lastname}
                                               onChange={(e) => handleFormFieldChange(
                                                   'lastname', e
                                               )}
                                    />
                                </Grid>
                                <Grid item xs={12} sm={6}>
                                    <FormControl fullWidth>
                                        <InputLabel>Gender</InputLabel>
                                        <Select label='gender' defaultValue={patient.gender} value={patient.gender}
                                                onChange={(e) => handleFormFieldChange(
                                                    'gender', e
                                                )}
                                        >
                                            <MenuItem value='MALE'>MALE</MenuItem>
                                            <MenuItem value='FEMALE'>FEMALE</MenuItem>
                                        </Select>
                                    </FormControl>
                                </Grid>
                                <Grid item xs={12} sm={6}>
                                    <TextField fullWidth type="date" label='Date Of Birth' placeholder='2011-01-01'
                                               defaultValue={patient.dob} value={patient.dob}
                                               onChange={(e) => handleFormFieldChange(
                                                   'dob', e
                                               )}
                                    />
                                </Grid>
                                <Grid item xs={12} sm={6}>
                                    <TextField
                                        fullWidth
                                        type='email'
                                        label='Email'
                                        placeholder='tjchidanika@gmail.com'
                                        defaultValue={patient.email}
                                        value={patient.email}
                                        onChange={(e) => handleFormFieldChange(
                                            'email', e
                                        )}
                                    />
                                </Grid>
                                <Grid item xs={12} sm={6}>
                                    <TextField fullWidth type="email" label='Emergency Contact'
                                               placeholder="tjchidanika" defaultValue={patient.emergencyContact}
                                               value={patient.emergencyContact}
                                               onChange={(e) => handleFormFieldChange(
                                                   'emergencyContact', e
                                               )}
                                    />
                                </Grid>
                                <Grid item xs={12} sm={6}>
                                    <TextField fullWidth label='Home Address' placeholder='Bindura'
                                               defaultValue={patient.homeAddress} value={patient.homeAddress}
                                               onChange={(e) => handleFormFieldChange(
                                                   'homeAddress', e
                                               )}
                                    />
                                </Grid>
                                <Grid item xs={12}>
                                    <Button type="submit" variant='contained' sx={{marginRight: 3.5}}>
                                        Save Changes
                                    </Button>
                                    <Button type='reset' variant='outlined' color='secondary'>
                                        Reset
                                    </Button>
                                </Grid>
                            </Grid>
                        </form>
                    </CardContent>
                </Grid>
            </Grid>
        </ApexChartWrapper>
    )
}

export default PatientDetails
