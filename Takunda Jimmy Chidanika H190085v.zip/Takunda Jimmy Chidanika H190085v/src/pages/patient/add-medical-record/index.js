// ** React Imports
import {useEffect, useState} from 'react'

// ** MUI Imports
import Card from '@mui/material/Card'
import Grid from '@mui/material/Grid'
import Button from '@mui/material/Button'
import Divider from '@mui/material/Divider'
import MenuItem from '@mui/material/MenuItem'
import TextField from '@mui/material/TextField'
import CardHeader from '@mui/material/CardHeader'
import InputLabel from '@mui/material/InputLabel'
import CardContent from '@mui/material/CardContent'
import CardActions from '@mui/material/CardActions'
import FormControl from '@mui/material/FormControl'
import Select from '@mui/material/Select'

// ** Third Party Imports
// ** Icons Imports
import ApexChartWrapper from "../../../@core/styles/libs/react-apexcharts";
import {useAppContext} from "../../../../context";

const AddMedicalRecord = () => {

    const {createMedicalRecord, getAuthorizedDoctors, userAddress, uploadFiles} = useAppContext();
    const [doctors, setDoctors] = useState([]);
    const [files, setFiles] = useState([]);
    const address = localStorage.getItem("userAddress");
    const [data, setData] = useState({
        heartRate: '',
        temperature: '',
    });
    useEffect(() => {
        fetchAuthDocs();
        const fetchData = async () => {
            const res = await fetch('http://localhost:9090/iot/latest/patient-1@gmail.com');
            const newData = await res.json();
            setData(newData);
            console.log(data);
        };

        // Fetch data initially and start timer
        fetchData();
        const timerId = setInterval(() => {
            fetchData();
        }, 1000);

        console.log(data);
        // Clean up timer when component unmounts
        return () => clearTimeout(timerId);
    }, []);

    console.log("Auth", userAddress);
    const fetchAuthDocs = async () => {
        const data = await getAuthorizedDoctors(localStorage.getItem("userAddress"));
        setDoctors(data);
        console.log(doctors);
    }

    const [form, setForm] = useState({
        patientAddress: '',
        doctorAddress: '',
        createdAt: '',
        symptoms: '',
        temperature: '',
        heartRate: '',
        diagnosis: '',
        treatment: '',
        files: [],
    })
    const handleFormFieldChange = (fieldName, e) => {
        setForm({...form, [fieldName]: e.target.value})
    }
    const handleFileChange = async (event) => {
        const links = await uploadFiles(event);
        setFiles(links);
    }

    const handleSubmit = async (e) => {
        const now = new Date();
        console.log(files);
        setForm({...form, patientAddress: address, createdAt: now.toString(), temperature: data.temperature,heartRate: data.heartRate});
        console.log(form);
        e.preventDefault();
        await createMedicalRecord({...form}, files);
    }

    return (
        <ApexChartWrapper>
            <Grid container spacing={6}>
                <Grid item xs={12}>
                    <Card>
                        <CardHeader title='Add Medical Record' titleTypographyProps={{variant: 'h6'}}/>
                        <Divider sx={{margin: 0}}/>
                        <form onSubmit={handleSubmit}>
                            <CardContent>
                                <Grid container spacing={5}>
                                    <Grid item xs={12} sm={6}>
                                        <FormControl fullWidth>
                                            <InputLabel id='form-layouts-separator-select-label'>Doctor</InputLabel>
                                            <Select
                                                label='Doctor'
                                                defaultValue=''
                                                value={form.doctorAddress}
                                                id='form-layouts-separator-select'
                                                labelId='form-layouts-separator-select-label'
                                                onChange={(e) => handleFormFieldChange(
                                                    'doctorAddress', e
                                                )}
                                            >
                                                {doctors.map((doc, index) => (
                                                    <MenuItem key={index}
                                                              value={doc.owner}>Dr {doc.doctorAddress} {doc.lastname} {doc.speciality}</MenuItem>
                                                ))}

                                            </Select>
                                        </FormControl>
                                    </Grid>
                                    <Grid item xs={12} sm={6}>
                                        <TextField
                                            fullWidth
                                            label='Temperature'
                                            placeholder='24'
                                            defaultValue={data.temperature}
                                            value={data.temperature}
                                            readonly={true}
                                        />
                                    </Grid>
                                    <Grid item xs={12} sm={6}>
                                        <TextField fullWidth
                                                   label='Heart Rate'
                                                   placeholder='78 BPM'
                                                   defaultValue={data.heartRate}
                                                   value={data.heartRate}
                                                   readOnly={true}
                                        />
                                    </Grid>
                                    <Grid item xs={12} sm={6}>
                                        <input
                                            type='file'
                                            value={form.files}
                                            multiple={true}
                                            onChange={handleFileChange}
                                        />
                                    </Grid>
                                    <Grid item xs={12}>
                                        <TextField
                                            fullWidth
                                            multiline
                                            minRows={3}
                                            value={form.symptoms}
                                            label='Symptoms'
                                            placeholder='Headache'
                                            onChange={(e) => handleFormFieldChange(
                                                'symptoms', e
                                            )}
                                        />
                                    </Grid>
                                </Grid>
                            </CardContent>
                            <Divider sx={{margin: 0}}/>
                            <CardActions>
                                <Button size='large' type='submit' sx={{mr: 2}} variant='contained'>
                                    Submit
                                </Button>
                                <Button size='large' color='secondary' variant='outlined'>
                                    Cancel
                                </Button>
                            </CardActions>
                        </form>
                    </Card>
                </Grid>
            </Grid>
        </ApexChartWrapper>
    )
}

export default AddMedicalRecord
