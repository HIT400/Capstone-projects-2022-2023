// // ** React Imports
// import {useEffect, useState} from 'react'
//
// // ** MUI Imports
// import Card from '@mui/material/Card'
// import Grid from '@mui/material/Grid'
// import Button from '@mui/material/Button'
// import Divider from '@mui/material/Divider'
// import MenuItem from '@mui/material/MenuItem'
// import TextField from '@mui/material/TextField'
// import CardHeader from '@mui/material/CardHeader'
// import InputLabel from '@mui/material/InputLabel'
// import CardContent from '@mui/material/CardContent'
// import CardActions from '@mui/material/CardActions'
// import FormControl from '@mui/material/FormControl'
// import Select from '@mui/material/Select'
//
// // ** Third Party Imports
//
// // ** Icons Imports
// import ApexChartWrapper from "../../../@core/styles/libs/react-apexcharts";
// import {useAppContext} from "../../../../context";
// import {useAddress} from "@thirdweb-dev/react";
// const AddPatient = () => {
//     const {createPatient, userAddress} = useAppContext();
//     const address = useAddress();
//     console.log("Add User", userAddress);
//     const [form, setForm] = useState({owner:'',
//         firstname: '',
//         middlename: '',
//         lastname: '',
//         gender: '',
//         dob: '',
//         email: '',
//         emergencyContact: '',
//         homeAddress: '',
//     })
//
//     const handleFormFieldChange = (fieldName, e) => {
//         setForm({...form, [fieldName]: e.target.value});
//     }
//
//     const setAddress= (()=>{
//
//         if(address){
//             setForm({...form, owner:address});
//         }
//         else {
//             setForm({...form, owner:userAddress});
//         }
//     })
//
//     const handleSubmit = async (e) => {
//         setAddress();
//         console.log(form);
//         e.preventDefault();
//         await createPatient({...form});
//     }
//     return (
//         <ApexChartWrapper>
//             <Grid container spacing={6}>
//                 <Grid item xs={12}>
//                     <Card>
//                         <CardHeader title='Add Patient' titleTypographyProps={{variant: 'h6'}}/>
//                         <Divider sx={{margin: 0}}/>
//                         <form onSubmit={handleSubmit}>
//                             <CardContent>
//                                 <Grid container spacing={5}>
//                                     <Grid item xs={12} sm={6}>
//                                         <TextField fullWidth
//                                                    label='Firstname'
//                                                    placeholder='Takunda'
//                                                    value={form.firstname}
//                                                    onChange={(e) => handleFormFieldChange(
//                                                        'firstname', e
//                                                    )}
//                                         />
//                                     </Grid>
//                                     <Grid item xs={12} sm={6}>
//                                         <TextField fullWidth
//                                                    label='Middlename'
//                                                    placeholder='Jimmy'
//                                                    value={form.middlename}
//                                                    onChange={(e) => handleFormFieldChange(
//                                                        'middlename', e
//                                                    )}
//                                         />
//                                     </Grid>
//                                     <Grid item xs={12} sm={6}>
//                                         <TextField
//                                             fullWidth
//                                             label='Lastname'
//                                             placeholder='Chidanika'
//                                             value={form.lastname}
//                                             onChange={(e) => handleFormFieldChange(
//                                                 'lastname', e
//                                             )}
//                                         />
//
//                                     </Grid>
//                                     <Grid item xs={12} sm={6}>
//                                         <FormControl fullWidth>
//                                             <InputLabel id='form-layouts-separator-select-label'>Gender</InputLabel>
//                                             <Select
//                                                 label='Gender'
//                                                 defaultValue=''
//                                                 value={form.gender}
//                                                 id='form-layouts-separator-select'
//                                                 labelId='form-layouts-separator-select-label'
//                                                 onChange={(e) => handleFormFieldChange(
//                                                     'gender', e
//                                                 )}
//                                             >
//                                                 <MenuItem value='MALE'>MALE</MenuItem>
//                                                 <MenuItem value='FEMALE'>FEMALE</MenuItem>
//
//                                             </Select>
//                                         </FormControl>
//                                     </Grid>
//                                     <Grid item xs={12} sm={6}>
//                                         <TextField fullWidth
//                                                    type='date'
//                                                    label='Date Of Birth'
//                                                    placeholder='2023-12-12'
//                                                    value={form.dob}
//                                                    onChange={(e) => handleFormFieldChange(
//                                                        'dob', e
//                                                    )}
//                                         />
//                                     </Grid>
//                                     <Grid item xs={12} sm={6}>
//                                         <TextField fullWidth
//                                                    type='email'
//                                                    label='Email'
//                                                    placeholder='tjchidanika@gmail.com'
//                                                    value={form.email}
//                                                    onChange={(e) => handleFormFieldChange(
//                                                        'email', e
//                                                    )}
//                                         />
//                                     </Grid>
//                                     <Grid item xs={12} sm={6}>
//                                         <TextField fullWidth
//                                                    type='email'
//                                                    label='Emergency Contact'
//                                                    placeholder='tjchidanika@gmail.com'
//                                                    value={form.emergencyContact}
//                                                    onChange={(e) => handleFormFieldChange(
//                                                        'emergencyContact', e
//                                                    )}
//                                         />
//                                     </Grid>
//                                     <Grid item xs={12} sm={6}>
//                                         <TextField fullWidth
//                                                    label='Home Address'
//                                                    placeholder='Gweru'
//                                                    value={form.homeAddress}
//                                                    onChange={(e) => handleFormFieldChange(
//                                                        'homeAddress', e
//                                                    )}
//                                         />
//                                     </Grid>
//                                 </Grid>
//                             </CardContent>
//                             <Divider sx={{margin: 0}}/>
//                             <CardActions>
//                                 <Button size='large' type='submit' sx={{mr: 2}} variant='contained'>
//                                     Submit
//                                 </Button>
//                                 <Button size='large' color='secondary' variant='outlined'>
//                                     Cancel
//                                 </Button>
//                             </CardActions>
//                         </form>
//                     </Card>
//                 </Grid>
//             </Grid>
//         </ApexChartWrapper>
//     )
// }
//
// export default AddPatient
