import ApexChartWrapper from "../../../@core/styles/libs/react-apexcharts";
import Grid from "@mui/material/Grid";
import CardHeader from "@mui/material/CardHeader";
import CardContent from "@mui/material/CardContent";
import Card from "@mui/material/Card";
import Box from "@mui/material/Box";
import Avatar from "@mui/material/Avatar";
import Typography from "@mui/material/Typography";
import {PlusBoxOutline} from "mdi-material-ui";
import {useEffect, useState} from "react";
import {useAppContext} from "../../../../context";
import AuthDoctorsTable from "../../../views/dashboard/AuthDoctorsTable";
import {useAddress} from "@thirdweb-dev/react";

const AuthorizedDoctors = () => {

    const [doctors, setDoctors] = useState([]);
    const {getAuthorizedDoctors, userAddress} = useAppContext();
    const address = useAddress();
    console.log("Auth Address", address);

    const fetchData = async () => {
        const data = await getAuthorizedDoctors(localStorage.getItem("userAddress"));
        console.log(data);
        setDoctors(data);
    }

    useEffect(async () => {
        fetchData();
    }, []);
    return (
        <ApexChartWrapper>
            <Grid container spacing={6}>
                <Grid item xs={12} md={12}>
                    <Card>
                        <CardHeader
                            title='Doctor Stats'
                            titleTypographyProps={{
                                sx: {
                                    mb: 1.0,
                                    lineHeight: '2rem !important',
                                    letterSpacing: '0.15px !important'
                                }
                            }}
                        />
                        <CardContent sx={{pt: theme => `${theme.spacing(3)} !important`}}>
                            <Grid container spacing={[5, 0]}>
                                <Grid item xs={12} sm={3}>
                                    <Box sx={{display: 'flex', alignItems: 'center'}}>
                                        <Avatar
                                            variant='rounded'
                                            sx={{
                                                mr: 3,
                                                width: 44,
                                                height: 44,
                                                boxShadow: 3,
                                                color: 'common.white',
                                                backgroundColor: `primary.main`
                                            }}
                                        >
                                            <PlusBoxOutline/>
                                        </Avatar>
                                        <Box sx={{display: 'flex', flexDirection: 'column'}}>
                                            <Typography variant='caption'>Total Number Of Authorized
                                                Doctors</Typography>
                                            <Typography variant='h6'>{doctors.length}</Typography>
                                        </Box>
                                    </Box>
                                </Grid>
                            </Grid>
                        </CardContent>
                    </Card>
                </Grid>
                <Grid item xs={12}>
                    <AuthDoctorsTable doctors={doctors}/>
                </Grid>
            </Grid>
        </ApexChartWrapper>
    )
}
export default AuthorizedDoctors
