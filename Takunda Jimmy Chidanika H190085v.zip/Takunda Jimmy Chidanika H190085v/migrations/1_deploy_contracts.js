const DoctorLib = artifacts.require("./DoctorLib.sol");
const MedLib = artifacts.require("./MedLib.sol");
const PatLib = artifacts.require("./PatLib.sol");
const HealthCare = artifacts.require("./HealthCare.sol");

module.exports = function (deployer) {
    deployer.deploy(DoctorLib).then(function() {
        deployer.link(DoctorLib, HealthCare);
        return deployer.deploy(MedLib);
    }).then(function() {
        deployer.link(MedLib, HealthCare);
        return deployer.deploy(PatLib);
    }).then(function() {
        deployer.link(PatLib, HealthCare);
        return deployer.deploy(HealthCare);
    });
};
