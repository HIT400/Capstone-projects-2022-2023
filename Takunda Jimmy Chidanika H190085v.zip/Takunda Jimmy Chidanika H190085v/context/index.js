import Web3 from 'web3';
import {createContext, useContext, useState} from "react";
import * as Constants from "./config";
import Contract from "web3-eth-contract";
import {useRouter} from "next/router";
import {useContract, useMetamask, useAddress, useWalletConnect} from "@thirdweb-dev/react";
import {create} from "ipfs-http-client";

export const appContext = createContext()

export const AppProvider = ({children}) => {
    const ipfs = create("http://localhost:5001");
    const router = useRouter();
    const [userAddress, setUserAddress] = useState('');
    const [userRole, setUserRole] = useState("PATIENT");
    const web3 = new Web3(new Web3.providers.HttpProvider(Constants.API_URL)); // replace with your Ganache RPC URL
    const contractAddress = Constants.CONTRACT_ADDRESS; // replace with the address of your deployed Patient contract
    const contract = new Contract(Constants.CONTRACT_ABI);
    contract.options.address = contractAddress;
    contract.setProvider(web3.currentProvider);


    // =====================================Patient=====================
    const createPatient = async (form) => {
        console.log("WEB3 FORM", form);
        try {
            const data = await contract.methods.createPatient(
                form.owner,
                form.firstname,
                form.middlename,
                form.lastname,
                form.gender,
                form.dob,
                form.email,
                form.emergencyContact,
                form.homeAddress,
            ).send({
                from: form.owner,
                gas: 1000000 // replace with the appropriate gas limit
            })

            await data.wait;
            await router.push("/patient");
            console.log("Saved Successfully");

        } catch (e) {
            console.log("Failed", e);
        }

    }
    const createMedicalRecord = async (form, files) => {
        try {

            const data = await contract.methods.createMedicalRecord(
                form.patientAddress,
                form.doctorAddress,
                form.createdAt,
                form.symptoms,
                form.temperature,
                form.heartRate,
                form.diagnosis,
                form.treatment,
                files,
            ).send({
                from: form.patientAddress,
                gas: 1000000 // replace with the appropriate gas limit
            })

            await data.wait;
            await router.push("/patient");
            console.log("Saved Successfully");

        } catch (e) {
            console.log("Failed", e);
        }

    }
    const getPatient = async (patientAddress) => {
        try {

            const data = await contract.methods.getPatient(patientAddress).call();
            console.log("Function Called Successfully");
            return {
                firstname: data.firstname,
                middlename: data.middlename,
                lastname: data.lastname,
                gender: data.gender,
                dob: data.dob,
                email: data.email,
                emergencyContact: data.emergencyContact,
                homeAddress: data.homeAddress,
            };
        } catch (e) {
            console.log("Failed", e);
        }
    }
    const updatePatient = async (form, address) => {
        try {
            const data = await contract.methods.updatePatient(
                address,
                form.firstname,
                form.middlename,
                form.lastname,
                form.gender,
                form.dob,
                form.email,
                form.emergencyContact,
                form.homeAddress,
            ).send({
                from:address,
                gas: 1000000 // replace with the appropriate gas limit
            })

            await data.wait;
            await router.push("/patient/details");
            console.log("Changed Successfully");

        } catch (e) {
            console.log("Failed", e);
        }

    }
    const grantAccess = async (form) => {
        try {
            const accounts = await web3.eth.getAccounts();
            console.log("DATA", form);
            const data = await contract.methods.grantAccess(
                form.patientAddress,
                form.doctorAddress,
            ).send({
                from: accounts[1],
                gas: 1000000 // replace with the appropriate gas limit
            })

            console.log(data);
            await router.push("/patient/authorized");
            console.log("Saved Successfully");

        } catch (e) {
            console.log("Failed", e);
        }
    }
    const revokeAccess = async (form) => {
        console.log(form);
        try {

            const data = await contract.methods.revokeAccess(
                form.patientAddress,
                form.doctorAddress,
            ).send({
                from:form.patientAddress,
                gas: 1000000 // replace with the appropriate gas limit
            })

            await router.push("/patient/authorized");
            console.log("Saved Successfully");

        } catch (e) {
            console.log("Failed", e);
        }
    }
    const getAuthorizedDoctors = async (patientAddress) => {
        const doctors = await contract.methods.getAuthorizedDoctors(patientAddress).call();
        console.log(doctors);
        return doctors.map((doctor) => ({
            owner: doctor.owner,
            firstname: doctor.firstname,
            middlename: doctor.middlename,
            lastname:doctor.lastname,
            gender: doctor.gender,
            email: doctor.email,
            dob: doctor.dob,
            speciality: doctor.speciality,
            shortDescription: doctor.shortDescription,
            physicalAddress: doctor.physicalAddress,
        }));
    }
    const getPatientEmail = async (patientAddress) => {
        try {
            const accounts = await web3.eth.getAccounts();
            console.log(accounts);
            const data = await contract.methods.getPatientEmail(
                patientAddress
            ).call()

            await data.wait;
            console.log(data);
            console.log("Saved Successfully");

        } catch (e) {
            console.log("Failed", e);
        }
    }
    const getMedicalRecords = async (patientAddress) => {
        const records = await contract.methods.getMedicalRecords(
            patientAddress,
        ).call();
        console.log("Records",records)
        const recs = records.map((record) => ({
            patientAddress: record.patientAddress,
            doctorAddress: record.doctorAddress,
            timestamp: record.createdAt,
            symptoms: record.symptoms,
            temperature: record.temperature,
            heartRate: record.heartRate,
            diagnosis: record.diagnosis,
            treatment: record.treatment,
            treated: record.treated,
            files: record.files,
        }));

        console.log("Function Called Successfully");
        console.log(recs);
        return recs;
    }
    const getDoctors = async () => {
        try {
            const doctors = await contract.methods.getDoctors().call();
            console.log(doctors);
            console.log("Function Called");
            return doctors.map((doctor) => ({
                doctorAddress: doctor.owner,
                firstname: doctor.firstname,
                middlename: doctor.middlename,
                lastname:doctor.lastname,
                gender: doctor.gender,
                email: doctor.email,
                dob: doctor.dob,
                speciality: doctor.speciality,
                shortDescription: doctor.shortDescription,
                physicalAddress: doctor.physicalAddress,
            }));
        }catch (e){
            console.log(e);
        }

    }
    const getMedicalRecord = async (recordId) => {
        try {

            const data = await contract.methods.getMedicalRecord(
                recordId
            ).call();

            console.log("Patient Record Function Called");
            return {
                recordId:data.recordId,
                patientAddress: data.patientAddress,
                doctorAddress: data.doctorAddress,
                createdAt:data.createdAt,
                symptoms: data.symptoms,
                temperature: data.temperature,
                heartRate: data.heartRate,
                diagnosis: data.diagnosis,
                treatment: data.treatment,
                files: data.files,
            };

        } catch (e) {
            console.log("Failed", e);
        }
    }
// ==========================Doctor==================================
    const createDoctor = async (form) => {
        try {
            console.log("WEB3",form)
            const data = await contract.methods.createDoctor(
                form.owner,
                form.firstname,
                form.firstname,
                form.lastname,
                form.gender,
                form.email,
                form.dob,
                form.speciality,
                form.shortDescription,
                form.physicalAddress,
            ).send({
                from:form.owner,
                gas: 1000000 // replace with the appropriate gas limit
            })

            await data.wait;
            await router.push("/doctor");
            console.log("Saved Successfully");

        } catch (e) {
            console.log("Failed", e);
        }

    }
    const updateDoctor = async (form) => {
        try {
            const accounts = await web3.eth.getAccounts();
            console.log(accounts);
            const data = await contract.methods.updateDoctor(
                form.owner,
                form.firstname,
                form.firstname,
                form.lastname,
                form.gender,
                form.dob,
                form.email,
                form.speciality,
                form.shortDescription,
                form.physicalAddress,
            ).send({
                from:form.owner,
                gas: 1000000 // replace with the appropriate gas limit
            })

            await data.wait;
            await router.push("/patient");
            console.log("Saved Successfully");

        } catch (e) {
            console.log("Failed", e);
        }

    }
    const getDoctor = async (doctorAddress) => {
        try {

            const data = await contract.methods.getDoctor(
                doctorAddress
            ).call();

            const record = {
                firstname:data.firstname,
                middlename:data.middlename,
                lastname: data.lastname,
                gender: data.gender,
                dob: data.dob,
                email: data.email,
                speciality:data.speciality,
                shortDescription:data.shortDescription,
                physicalAddress: data.physicalAddress,
            }
            console.log(record);
            console.log("Function Called Successfully");
            return record;

        } catch (e) {
            console.log("Failed", e);
        }
    }
    const getDoctorEmail = async () => {
        try {
            const accounts = await web3.eth.getAccounts();
            console.log(accounts);
            const data = await contract.methods.getDoctorEmail(
                "0xCd2333648470ef1525c9cbd41A891967270574be",
            ).call()

            console.log(data);
            console.log("Saved Successfully");

        } catch (e) {
            console.log("Failed", e);
        }
    }
    const updateMedicalRecord = async (form) => {
        try {
            const data = await contract.methods.updateMedicalRecord(
                form.recordId,
                form.patientAddress,
                form.doctorAddress,
                form.treatedAt,
                form.symptoms,
                form.temperature,
                form.heartRate,
                form.diagnosis,
                form.treatment,
                ["1","2"],
            ).send({
                from: form.doctorAddress,
                gas: 1000000 // replace with the appropriate gas limit
            })

            await data.wait;
            await router.push("/patient");
            console.log("Saved Successfully");

        } catch (e) {
            console.log("Failed", e);
        }

    }

    const getPatientByDoctorId = async (doctorAddress) => {
        try {
            const patients = await contract.methods.getPatientByDoctorId(doctorAddress).call();
            return patients.map((patient) => ({
                patientAddress: patient.owner,
                firstname: patient.firstname,
                middlename: patient.middlename,
                lastname:patient.lastname,
                gender: patient.gender,
                email: patient.email,
                dob: patient.dob,
                emergencyContact: patient.emergencyContact,
                homeAddress: patient.homeAddress
            }));
        }catch (e){
            console.log(e);
        }
    }

    const getMedicalRecordsByDoctor = async (doctorAddress) => {
        const records = await contract.methods.getMedicalRecordsByDoctor(
            doctorAddress,
        ).call();
        console.log("Records", records);
        const recs = records.map((record) => ({
            recordId: record.recordId,
            patientAddress: record.patientAddress,
            doctorAddress: record.doctorAddress,
            timestamp: record.createdAt,
            symptoms: record.symptoms,
            temperature: record.temperature,
            heartRate: record.heartRate,
            diagnosis: record.diagnosis,
            treatment: record.treatment,
            treated: record.treated,
            files: record.files,
        }));

        console.log("Function Called Successfully");
        return recs;
    }
    const uploadFiles = async (event) => {
        try {
            const files = event.target.files;
            const fileLinks=[];
            console.log(files);

            for (let i = 0; i < files.length; i++){
                const file = event.target.files[i];
                const result = await ipfs.add(file);
                fileLinks.push(`https://ipfs.io/ipfs/${result.path}`)

            }

            return fileLinks;

        } catch (e) {
            console.log(e);
        }

    }
    const address = useAddress();
    return (
        <appContext.Provider
            value={{
                createPatient,
                createMedicalRecord,
                getPatient,
                getPatientEmail,
                grantAccess,
                revokeAccess,
                updatePatient,
                getAuthorizedDoctors,
                getMedicalRecords,
                getMedicalRecord,
                createDoctor,
                updateDoctor,
                updateMedicalRecord,
                getDoctor,
                getDoctorEmail,
                getDoctors,
                address,
                getPatientByDoctorId,
                userAddress,
                setUserAddress,
                userRole,
                setUserRole,
                uploadFiles,
                getMedicalRecordsByDoctor,
            }}
        >
            {children}
        </appContext.Provider>
    )
}

export const useAppContext=()=>{
    return useContext(appContext);
}