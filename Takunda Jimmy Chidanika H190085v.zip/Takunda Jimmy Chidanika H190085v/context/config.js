import HealthCare from "../build/contracts/HealthCare.json"
export const API_URL = "HTTP://127.0.0.1:8545";
export const PRIVATE_KEY = "";
export const CONTRACT_ADDRESS="0x60d2f53AC187a423Ba77df20757D433dC49372cE";
export const CONTRACT_ABI = HealthCare.abi;
