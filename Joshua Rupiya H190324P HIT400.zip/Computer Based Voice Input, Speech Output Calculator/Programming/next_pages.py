###########$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
from tkinter import *
import tkinter as tk
from tkinter import messagebox
import ast
import sys
import operator
from unittest import result
import pyttsx3
import pyaudio
import speech_recognition as s_r

def move_back_page():
    root3.withdraw()
    instruction()
    
def instruction():
    global root2
    root2 = tk.Tk()
    root2.geometry('925x500+300+200')
    root2.title('Instruction')
    
  
    main_frame = tk.Frame(root2)

    page_1 = tk.Frame(main_frame)
    page_1_lb = tk.Label(page_1, text='Things You Need To Know.\n\n', font=('Microsoft Yahei UI Light',23,'bold'))
    page_1_lb.pack()
    page_1_lb = tk.Label(page_1, text='i) Input numbers from 0 - 99. \n\n\nii) The operators available include addition, subtraction, multiplication and division.', font=('Microsoft Yahei UI Light',13))
    page_1_lb.pack()


    page_1.pack(pady=100)
    
    main_frame.pack(fill=tk.BOTH, expand=True)
        
    def move_next_page():
        root2.withdraw()
        global root3
        root3 = tk.Tk()
        root3.geometry('925x500+300+200')
        root3.title('Limits')
        
        main_frame = tk.Frame(root3)

        page_2 = tk.Frame(main_frame)
        page_2_lb = tk.Label(page_2, text='How To Use.\n\n', font=('Microsoft Yahei UI Light',23,'bold'))
        page_2_lb.pack()
        page_2_lb = tk.Label(page_2, text='Click on start and speak with the calculator.\n\n\n\nYou can say something like;"Three Plus Three"', font=('Microsoft Yahei UI Light',13))
        page_2_lb.pack()
        
        page_2.pack(pady=100)
       

        main_frame.pack(fill=tk.BOTH, expand=True)
        
        bottom_frame = tk.Frame(root3)
        # back button UI,  command is using the move back page function
        back_btn = tk.Button(bottom_frame, text='Back',
                             font=('Bold', 12),
                             bg='#1877f2', fg='white', width=8,
                             command=move_back_page)
        back_btn.pack(side=tk.LEFT, padx=10)
##        # next button UI, command is using the move next page function
##        next_btn = tk.Button(bottom_frame, text='Next',
##                             font=('Bold', 12),
##                             bg='#1877f2', fg='white', width=8,
##                             command=move_next_page)
##        next_btn.pack(side=tk.RIGHT, padx=10)

         # lets go button UI, command is using the move next page function
        lets_go_btn = tk.Button(bottom_frame, text='lets go',
                             font=('Bold', 12),
                             bg='#1877f2', fg='white', width=8,
                             command=lets_go)
        lets_go_btn.pack(side=tk.RIGHT, padx=10)


        bottom_frame.pack(side=tk.BOTTOM, pady=10)

            
    def lets_go():
    #######mainnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnlast page code
        # Initialize Tkinter window and listbox
        root = tk.Tk()
        root.geometry('925x500+300+200')
        root.title('VoiceCalculator')
        root2.withdraw()
        root3.withdraw()               
    ####code for main recognition starts hre going down
        def run_program():
            r = s_r.Recognizer()
            my_mic_device = s_r.Microphone(device_index=1)
            with my_mic_device as source:
                
                def speak(text):
                    engine = pyttsx3.init()
                    engine.say(text)
                    engine.runAndWait()
                print("Say what you want to calculate, example: 3 plus 3")
                speak("say what you want to calculate ,example:3 plus 3. I am listening....")
                
                r.adjust_for_ambient_noise(source)
                audio = r.listen(source)
    ##                while True:
                try:
                     my_string = r.recognize_google(audio)
                     print(my_string)
                except s_r.UnknownValueError:
                     print("sorry, i didnt catch that. please try again.")
                except s_r.RequestError as e:
                     print(f"Could not request results from Google Speech Recognition service: {e}")

                    
            # Create a new thread to run the recognition function
           # thread = threading.Thread(target=recognize_google)
           # thread.start()

            def get_operator_fn(op):
                return {
                    '+' : operator.add,
                    '-' : operator.sub,
                    'x' : operator.mul,
                    'divided' :operator.__truediv__,
                    '/' : operator.__truediv__,
                    'Mod' : operator.mod,
                    'mod' : operator.mod,
                    '^' : operator.xor,
                    '*' : operator.mul,
                }[op]

            def eval_binary_expr(op1, oper, op2):
                op1, op2 = int(op1), int(op2)
                return get_operator_fn(oper)(op1, op2)

            def speak(text):
                engine = pyttsx3.init()
                engine.say(text)
                engine.runAndWait()
           
            def main():
                while True:
                    try:
                        my_string_parts = my_string.split()
                        operand1 = my_string_parts[0]
                        operator = my_string_parts[1]
                        operand2 = my_string_parts[2]
                        result = eval_binary_expr(operand1, operator, operand2)
                        if result is not None:
                            print(f"the result is: {result}")
                            
                            text_widget.insert(tk.END, f"{operand1}{operator}{operand2}={result}\n")
                            text_widget.update()
                            
                            speak(f"{operand1}{operator}{operand2}={result}")
                            
                            run_program()
                            
    ##                            break
                        else:
                            print("sorry, i didnt understand your input. please try again.")
                            
    ##                                speak("sorry, i didnt understand your input. please try again.")
                            
                            speak("please try again")
                            
    ##                                run_program()

                    except:
                       pass

            if __name__ == "__main__":
                main()
                
        text_widget = tk.Text(root, height=20, width=50,font=('Microsoft Yahei UI Light',9))
        text_widget.pack()
        
        def save_text():
            # Get the text from the text widget
            text = text_widget.get("1.0", tk.END)

            # Write the text to a file
            with open("history.txt", "a") as file:
                file.write(text)

       

        page_1 = tk.Frame(main_frame)
        page_1_lb = tk.Label(page_1, text='Start ', font=('Bold', 20))
        page_1_lb.pack()

        page_2 = tk.Frame(main_frame)
        page_2_lb = tk.Label(page_2, text='stop', font=('Bold', 20))
        page_2_lb.pack()

        page_3 = tk.Frame(main_frame)
        page_3_lb = tk.Label(page_3, text='Save', font=('Bold', 20))
        page_3_lb.pack()

        page_4 = tk.Frame(main_frame)
        page_4_lb = tk.Label(page_4, text='exit', font=('Bold', 20))
        page_4_lb.pack()

        # Funciones de cambio de página
        def open_page1():
            page_1.pack()
            page_2.pack_forget()
            page_3.pack_forget()
            page_4.pack_forget()

        def open_page2():
            page_1.pack_forget()
            page_2.pack()
            page_3.pack_forget()
            page_4.pack_forget()

        def open_page3():
            page_1.pack_forget()
            page_2.pack_forget()
            page_3.pack()
            page_4.pack_forget()

        def open_page4():
            page_1.pack_forget()
            page_2.pack_forget()
            page_3.pack_forget()
            page_4.pack()
        def stop_button():
            run_program.pack_forget()
            stop_button.pack()
            page_3.pack_forget()
            page_4.pack_forget()
            
        def main_exit():
            root.destroy()
            
        # Botones de navegación
        nav_frame = tk.Frame(root)

        btn_page1 = tk.Button(nav_frame, text='Start', font=('Bold', 12), bg='#1877f2', fg='white', width=12, command=run_program)
        btn_page1.pack(side=tk.LEFT, padx=10)

        btn_page2 = tk.Button(nav_frame, text='Stop', font=('Bold', 12), bg='#1877f2', fg='white', width=12, command=stop_button)
        btn_page2.pack(side=tk.LEFT, padx=10)

        btn_page3 = tk.Button(nav_frame, text='Save', font=('Bold', 12), bg='#1877f2', fg='white', width=12, command=save_text)
        btn_page3.pack(side=tk.LEFT, padx=10)

        btn_page4 = tk.Button(nav_frame, text='Exit', font=('Bold', 12), bg='#1877f2', fg='white', width=12, command=main_exit)
        btn_page4.pack(side=tk.LEFT, padx=10)

        nav_frame.pack(side=tk.TOP, pady=10)

        root.mainloop()
    ##############mainnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnlast code end here
    bottom_frame = tk.Frame(root2)
    # back button UI,  command is using the move back page function
    back_btn = tk.Button(bottom_frame, text='Back',
                         font=('Bold', 12),
                         bg='#1877f2', fg='white', width=8
                         )
    back_btn.pack(side=tk.LEFT, padx=10)
    # next button UI, command is using the move next page function
    next_btn = tk.Button(bottom_frame, text='Next',
                         font=('Bold', 12),
                         bg='#1877f2', fg='white', width=8,
                         command=move_next_page)
    next_btn.pack(side=tk.RIGHT, padx=10)

##     # lets go button UI, command is using the move next page function
##    lets_go_btn = tk.Button(bottom_frame, text='lets go',
##                         font=('Bold', 12),
##                         bg='#1877f2', fg='white', width=8,
##                         command=lets_go)
##    lets_go_btn.pack(side=tk.RIGHT, padx=10)


    bottom_frame.pack(side=tk.BOTTOM, pady=10)

    root2.mainloop()


    ############$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$                



