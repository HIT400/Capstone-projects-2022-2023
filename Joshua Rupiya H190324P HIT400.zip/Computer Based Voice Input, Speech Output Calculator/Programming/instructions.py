from tkinter import *
import tkinter as tk
from tkinter import messagebox
import ast
import sys
import operator
from unittest import result
import pyttsx3
import pyaudio
import speech_recognition as s_r


root = tk.Tk()
root.geometry('925x500+300+200')
root.title('Instruction')
##        root.configure(bg='#fff')
       

main_frame = tk.Frame(root)
        
page_1 = tk.Frame(main_frame)
page_1_lb = tk.Label(page_1, text='Things You Need To Know.\n\n', font=('Microsoft Yahei UI Light',23,'bold'))
page_1_lb.pack()
page_1_lb = tk.Label(page_1, text='i) Input numbers from 0 - 99. \n\n\nii) The operators available include addition, subtraction, multiplication and division.', font=('Microsoft Yahei UI Light',13))
page_1_lb.pack()
      

page_1.pack(pady=100)

page_2 = tk.Frame(main_frame)
page_2_lb = tk.Label(page_2, text='How To Use.\n\n', font=('Microsoft Yahei UI Light',23,'bold'))
page_2_lb.pack()
page_2_lb = tk.Label(page_2, text='Click on start and speak with the calculator.\n\n\n\nYou can say something like;"Three Plus Three"', font=('Microsoft Yahei UI Light',13))
page_2_lb.pack()

       

main_frame.pack(fill=tk.BOTH, expand=True)


    #pages variable of all the UI
pages = [page_1, page_2]

count = 0

def move_next_page():
    
    
    global count
    
    count += 1
    
         
    if count < len(pages):
        
        pages[count-1].pack_forget()
        pages[count].pack(pady=100)
        
def move_back_page():
    
    global count
    
    if not count == 0:
        
        for p in pages:
            
            p.pack_forget()
        
            count -= 1
            # counts how many pages
            page = pages[count]
            
            page.pack(pady=100)

                
def lets_go():
    
#######mainnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnlast page code
            # Initialize Tkinter window and listbox
    root = tk.Tk()
    root.geometry('925x500+300+200')
    root.title('VoiceCalculator')

bottom_frame = tk.Frame(root)

# back button UI,  command is using the move back page function
back_btn = tk.Button(bottom_frame, text='Back',
                     
                     
                     font=('Bold', 12),
                     bg='#1877f2', fg='white', width=8,
                     command=move_back_page)

back_btn.pack(side=tk.LEFT, padx=10)
        
        # next button UI, command is using the move next page function
next_btn = tk.Button(bottom_frame, text='Next',
                     
                     font=('Bold', 12),
                     bg='#1877f2', fg='white', width=8,
                     command=move_next_page)
next_btn.pack(side=tk.RIGHT, padx=10)

         # lets go button UI, command is using the move next page function
lets_go_btn = tk.Button(bottom_frame, text='lets go',
                        
                        font=('Bold', 12),
                        bg='#1877f2', fg='white', width=8,
                        command=lets_go)
lets_go_btn.pack(side=tk.RIGHT, padx=10)



bottom_frame.pack(side=tk.BOTTOM, pady=10)
            
           
