## voice input speech output calculator
Computer based Voice input, speech output calculator is an application that performs mathematical calculation by receiving input from speech and outputs the result in both speech and text format.

## Problem statement
> The purpose of this project is to address the challenges faced by early childhood development pupils in their math calculations. Traditional  calculators and writing out calculations may be difficult for young learners who are still developing their math skills. Hence, the need for an innovative and accessible solution that can assist them with their calculations while promoting the use of technology in education.The proposed solution is a speech-based calculator that utilizes speech recognition technology to recognize various mathematical operations, including addition, subtraction, multiplication, and division. The project requires the development of accurate and reliable speech recognition software that can provide correct results to the user.The ultimate goal of this project is to create a user-friendly and effective tool for early childhood development that can improve their math skills and facilitate their learning experience. To achieve this goal, the effectiveness of the speech-based calculator will be assessed through user testing and feedback. The project team will continuously work on improving the system based on the feedback received to ensure that it meets the needs of the target users.

## Getting started
> In order to run the program navigate to `Programming` folder and run `program`. To remove the exisiting datasheet for login options , delete the file `datasheet` in the same folder.

## Description
- Unlike the conventional calculators in which users have to input mathematical problems by punching a bunch of keys, this application allows users to speak their mathematical problems. It then performs the necessary operations and returns the solution in speech and text format.<br>
- It is a GUI application with tkinter that utilizes the Windows Desktop Speech technology types to implement speech recognition. 
- It references a goolge API speech recognition grammar which defines the constraints for speech recognition. It defines what the speech recognition engine can recognize as meaningful input; therefore, any other grammar would not be recognized by the calculator.
- This application is completely written in the python programming language.

## Required Libraries:
* pyttsx3
* pyaudio
* numpy
* speech_recognition
* tkinter
* It is also recommended to have python 3.11.4 installed

## Things You Need to Know
- The application only works with the number range 0 - 99.
- It performs only four mathematical operations: Multiplication, Addition, Subtraction and Division.
- The following grammar are recognized for the mathematical operations: "plus", "adds", "minus", "times"."multiply","divided" and "divides".

## How it Works
- Click on the start button or say start.
- Speak the mathematical problem to the calculator. For example: "forty plus ten"
- Once the start button is clicked, continuous speech recognition is activated therefore you don't have to click the start button again for another input.
- Click on the stop button to stop the recognition.
- Click the save button to save the current user data to a computer file.
- click exit to quit the application

## documented papers for this project
- for the final project documents, navigate to `Paper` folder, it also includes the documentation, technical paper and poster.

## Visuals
Here's a Screenshot!:
![alt text](https://github.com/josh-Rups/Start.png "UI Screenshot")


